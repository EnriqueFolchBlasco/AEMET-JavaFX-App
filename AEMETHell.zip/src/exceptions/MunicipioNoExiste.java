package exceptions;

public class MunicipioNoExiste extends Exception{
	
	
	
}
