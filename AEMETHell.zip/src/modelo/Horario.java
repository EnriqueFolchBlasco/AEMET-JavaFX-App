package modelo;

public class Horario {

	String v0024;
	String v0012;
	String v1224;
	String v0006;
	String v0612;
	String v1218;
	String v1824;
	
	public Horario(String v0024, String v0012, String v1224, String v0006, String v0612, String v1218, String v1824) {
		super();
		this.v0024 = v0024;
		this.v0012 = v0012;
		this.v1224 = v1224;
		this.v0006 = v0006;
		this.v0612 = v0612;
		this.v1218 = v1218;
		this.v1824 = v1824;
	}

	public String getV0024() {
		return v0024;
	}

	public void setV0024(String v0024) {
		this.v0024 = v0024;
	}

	public String getV0012() {
		return v0012;
	}

	public void setV0012(String v0012) {
		this.v0012 = v0012;
	}

	public String getV1224() {
		return v1224;
	}

	public void setV1224(String v1224) {
		this.v1224 = v1224;
	}

	public String getV0006() {
		return v0006;
	}

	public void setV0006(String v0006) {
		this.v0006 = v0006;
	}

	public String getV0612() {
		return v0612;
	}

	public void setV0612(String v0612) {
		this.v0612 = v0612;
	}

	public String getV1218() {
		return v1218;
	}

	public void setV1218(String v1218) {
		this.v1218 = v1218;
	}

	public String getV1824() {
		return v1824;
	}

	public void setV1824(String v1824) {
		this.v1824 = v1824;
	}

	@Override
	public String toString() {
		return "Horario [v0024=" + v0024 + ", v0012=" + v0012 + ", v1224=" + v1224 + ", v0006=" + v0006 + ", v0612="
				+ v0612 + ", v1218=" + v1218 + ", v1824=" + v1824 + "]";
	}
	
	
	
	
}


